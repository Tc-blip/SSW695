Shopping Expert
==
INTRODUCTION
--
Team member： Yukai Tan, Cheng Tian 
  
An offline shopping store recommendation software. We would like to display brief information on the map. Let people better understand stores that they don’t know or have never been to. Based on the map, we have two display modes. When there are more than one stores within the map range, our software will list all clothing stores, shoe stores and bag stores. Giving some brief description and tags of the store at that time. After zoom in or zoom out, when only one store is displayed within map range, our interface will show up comprehensive information of that store. Describe what type of the store is , what is the highlight of this brand, who (celebrities) often visited, give some icons and examples. 

**Interface**

![](https://github.com/Tc-blip/SSW695/blob/master/pic/interface.png)


Contents
--
├── Readme.md                   
├── Document                             
├── Pic   
└── tools
